Configuration DeployWebPage 
{
    node ("localhost") 
    {
        WindowsFeature IIS 
        {
            Ensure = "Present"
            Name = "Web-Server"
        }

        File WebPage 
        {
            Ensure = "Present"
            DestinationPath = "C:\inetpub\wwwroot\index.html"
            Force = $true
            Type = "File"
            Contents = "<html><body><img src='https://github.com/Girls-in-Tech-Poland/Az900/raw/master/img/girls-in-tech-poland.png'/><h1>Looks like my AZ-900 workshop is going great!</h1></body></html>"
        }
    }
}