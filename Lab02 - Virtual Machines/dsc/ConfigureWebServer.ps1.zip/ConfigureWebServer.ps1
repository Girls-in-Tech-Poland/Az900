Configuration DeployWebPage 
{
    node ("localhost") 
    {
        WindowsFeature IIS 
        {
            Ensure = "Present"
            Name = "Web-Server"
        }

        File WebPage 
        {
            Ensure = "Present"
            DestinationPath = "C:\inetpub\wwwroot\index.html"
            Force = $true
            Type = "File"
            Contents = "<html><body>Hello from DSC!</body></html>"
        }
    }
}